**1、安装 node.js**

#下载：https://nodejs.org/en/

cmd输入``node -v ``和``npm -v``查看是否安装成功

**2、安装 electron**
命令行下载淘宝镜像命令工具``cnpm``
```shell
npm install cnpm -g --registry=http://registry.npm.taobao.org
```
用``cnpm``命令安装``electron``
```shell
cnpm install electron -g
```
``cmd``输入``electron -v``查看是否安装成功

**3、运行**
在项目目录下运行：
```shell
electron .
```