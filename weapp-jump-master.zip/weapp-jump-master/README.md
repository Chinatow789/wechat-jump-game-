## 跳一跳 小程序

### 1、安装

   * 克隆代码, 导入开发者工具

   ![](http://image.aiotv.cn/weapp-jump-0.png)
   
   
### 2、运行

   ![](http://image.aiotv.cn/weapp-jump-2.png)
